package com.deneme.urlshortener;

public class ShortenResponse {

    private String link;

    public String getLink() {
        return link;
    }

    public void setLink(String link) {
        this.link = link;
    }
}